Image Finder Pro Module for OpenCart 3
======================================

Module Name: Image Finder Pro
Version: 1.1
Author: Your Name

Description:
------------
Advanced module for finding and managing unused images in OpenCart 3.

New Features in v1.1:
---------------------
✅ Image preview in modal window
✅ Multiple file selection with checkboxes
✅ Bulk delete operations
✅ File information (size, dimensions)
✅ Select All / Unselect All functionality
✅ Enhanced user interface
✅ Better error handling

Installation:
-------------
1. Upload the contents of the 'upload' folder to your OpenCart root directory
2. Go to Extensions > Installer and upload the install.xml file
3. Go to Extensions > Extensions > Modules and find "Image Finder Pro"
4. Install and configure the module

Usage:
------
1. Configure search options:
   - Recursive Search: Search in subdirectories
   - Enable Preview: Show image previews
   - Max Files: Limit files to check
2. Click "Find Unused Images"
3. Use checkboxes to select multiple files
4. Use "Select All" / "Unselect All" for bulk operations
5. Preview images by clicking "Preview" button
6. Delete selected images with "Delete Selected" button

Security Notes:
---------------
- Always backup your files before deletion
- Module includes confirmation dialogs for deletion
- Files are only deleted from /image/catalog/ directory
- User permissions are strictly checked

Support:
--------
For support contact: your@email.com

License:
--------
This module is released under the Open Software License (OSL 3.0)
