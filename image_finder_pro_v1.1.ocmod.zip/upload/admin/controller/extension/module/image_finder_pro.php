<?php
class ControllerExtensionModuleImageFinderPro extends Controller {
    private $error = array();

    public function index() {
        $this->load->language('extension/module/image_finder_pro');

        $this->document->setTitle($this->language->get('heading_title'));

        // Добавляем CSS и JavaScript
        $this->document->addStyle('view/stylesheet/image_finder_pro.css');
        $this->document->addScript('view/javascript/image_finder_pro.js');

        $data['breadcrumbs'] = array();

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_extension'),
            'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true)
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('extension/module/image_finder_pro', 'user_token=' . $this->session->data['user_token'], true)
        );

        $data['action'] = $this->url->link('extension/module/image_finder_pro', 'user_token=' . $this->session->data['user_token'], true);
        $data['cancel'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true);
        
        $data['user_token'] = $this->session->data['user_token'];
        $data['base_url'] = HTTP_CATALOG;
        
        // Получаем настройки
        if (isset($this->request->post['module_image_finder_pro_recursive'])) {
            $data['module_image_finder_pro_recursive'] = $this->request->post['module_image_finder_pro_recursive'];
        } else {
            $data['module_image_finder_pro_recursive'] = $this->config->get('module_image_finder_pro_recursive');
        }
        
        if (isset($this->request->post['module_image_finder_pro_max_files'])) {
            $data['module_image_finder_pro_max_files'] = $this->request->post['module_image_finder_pro_max_files'];
        } else {
            $data['module_image_finder_pro_max_files'] = $this->config->get('module_image_finder_pro_max_files') ?: 1000;
        }
        
        if (isset($this->request->post['module_image_finder_pro_preview'])) {
            $data['module_image_finder_pro_preview'] = $this->request->post['module_image_finder_pro_preview'];
        } else {
            $data['module_image_finder_pro_preview'] = $this->config->get('module_image_finder_pro_preview');
        }

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('extension/module/image_finder_pro', $data));
    }

    public function save() {
        $this->load->language('extension/module/image_finder_pro');

        $json = array();

        if (!$this->user->hasPermission('modify', 'extension/module/image_finder_pro')) {
            $json['error'] = $this->language->get('error_permission');
        } else {
            $this->load->model('setting/setting');
            
            $settings = array(
                'module_image_finder_pro_status' => 1,
                'module_image_finder_pro_recursive' => isset($this->request->post['module_image_finder_pro_recursive']) ? 1 : 0,
                'module_image_finder_pro_max_files' => isset($this->request->post['module_image_finder_pro_max_files']) ? (int)$this->request->post['module_image_finder_pro_max_files'] : 1000,
                'module_image_finder_pro_preview' => isset($this->request->post['module_image_finder_pro_preview']) ? 1 : 0
            );
            
            $this->model_setting_setting->editSetting('module_image_finder_pro', $settings);
            
            $json['success'] = $this->language->get('text_success');
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    public function findUnusedImages() {
        $json = array();

        $this->load->language('extension/module/image_finder_pro');

        if (!$this->user->hasPermission('modify', 'extension/module/image_finder_pro')) {
            $json['error'] = $this->language->get('error_permission');
        } else {
            $recursive = isset($this->request->post['recursive']) ? (bool)$this->request->post['recursive'] : false;
            $max_files = isset($this->request->post['max_files']) ? (int)$this->request->post['max_files'] : 1000;

            $unused_images = $this->findUnusedImagesInDatabase($recursive, $max_files);
            
            $json['success'] = $this->language->get('text_success_find');
            $json['images'] = $unused_images;
            $json['total'] = count($unused_images);
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    public function deleteImages() {
        $json = array();

        $this->load->language('extension/module/image_finder_pro');

        if (!$this->user->hasPermission('modify', 'extension/module/image_finder_pro')) {
            $json['error'] = $this->language->get('error_permission');
        } else {
            $images_to_delete = isset($this->request->post['images']) ? $this->request->post['images'] : array();
            $deleted = array();
            $errors = array();

            foreach ($images_to_delete as $image_path) {
                $full_path = DIR_IMAGE . $image_path;
                
                // Проверяем, что файл существует и находится в разрешенной директории
                if (file_exists($full_path) && strpos($image_path, 'catalog/') === 0) {
                    if (unlink($full_path)) {
                        $deleted[] = $image_path;
                        
                        // Пытаемся удалить кэшированные версии изображений
                        $this->deleteCachedImages($image_path);
                    } else {
                        $errors[] = $this->language->get('error_delete') . ': ' . $image_path;
                    }
                } else {
                    $errors[] = $this->language->get('error_file_not_found') . ': ' . $image_path;
                }
            }

            $json['success'] = sprintf($this->language->get('text_success_delete'), count($deleted));
            $json['deleted'] = $deleted;
            $json['errors'] = $errors;
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    private function deleteCachedImages($image_path) {
        $cache_dir = DIR_IMAGE . 'cache/';
        $image_name = pathinfo($image_path, PATHINFO_FILENAME);
        $image_extension = pathinfo($image_path, PATHINFO_EXTENSION);
        
        // Ищем файлы в кэше, которые могут быть связаны с этим изображением
        $cache_files = glob($cache_dir . '*' . $image_name . '*.' . $image_extension);
        foreach ($cache_files as $cache_file) {
            if (file_exists($cache_file)) {
                unlink($cache_file);
            }
        }
    }

    private function findUnusedImagesInDatabase($recursive = false, $max_files = 1000) {
        $unused_images = array();
        
        // Получаем все изображения из базы данных
        $db_images = $this->getAllDatabaseImages();
        
        // Получаем все файлы изображений
        $file_images = $this->getAllImageFiles($recursive, $max_files);
        
        // Находим неиспользуемые изображения
        foreach ($file_images as $file_image) {
            if (!in_array($file_image, $db_images)) {
                $unused_images[] = $file_image;
            }
        }

        return $unused_images;
    }

    private function getAllDatabaseImages() {
        $images = array();

        // Изображения товаров
        $query = $this->db->query("SELECT image FROM " . DB_PREFIX . "product WHERE image != ''");
        foreach ($query->rows as $result) {
            $images[] = $result['image'];
        }

        // Дополнительные изображения товаров
        $query = $this->db->query("SELECT image FROM " . DB_PREFIX . "product_image WHERE image != ''");
        foreach ($query->rows as $result) {
            $images[] = $result['image'];
        }

        // Изображения категорий
        $query = $this->db->query("SELECT image FROM " . DB_PREFIX . "category WHERE image != ''");
        foreach ($query->rows as $result) {
            $images[] = $result['image'];
        }

        // Изображения производителей
        $query = $this->db->query("SELECT image FROM " . DB_PREFIX . "manufacturer WHERE image != ''");
        foreach ($query->rows as $result) {
            $images[] = $result['image'];
        }

        // Изображения баннеров
        $query = $this->db->query("SELECT image FROM " . DB_PREFIX . "banner_image WHERE image != ''");
        foreach ($query->rows as $result) {
            $images[] = $result['image'];
        }

        return array_unique($images);
    }

    private function getAllImageFiles($recursive = false, $max_files = 1000) {
        $image_files = array();
        $image_dir = DIR_IMAGE . 'catalog/';
        $allowed_extensions = array('jpg', 'jpeg', 'png', 'gif', 'webp');

        if (!is_dir($image_dir)) {
            return $image_files;
        }

        if ($recursive) {
            $iterator = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator($image_dir, RecursiveDirectoryIterator::SKIP_DOTS),
                RecursiveIteratorIterator::SELF_FIRST
            );
        } else {
            $iterator = new DirectoryIterator($image_dir);
        }

        $count = 0;
        foreach ($iterator as $file) {
            if ($count >= $max_files) break;

            if ($file->isFile()) {
                $extension = strtolower(pathinfo($file->getFilename(), PATHINFO_EXTENSION));
                
                if (in_array($extension, $allowed_extensions)) {
                    $full_path = $file->getPathname();
                    $relative_path = str_replace(DIR_IMAGE, '', $full_path);
                    $image_files[] = $relative_path;
                    $count++;
                }
            }
        }

        return $image_files;
    }

    public function install() {
        $this->load->model('setting/setting');
        
        $settings = array(
            'module_image_finder_pro_status' => 1,
            'module_image_finder_pro_recursive' => 1,
            'module_image_finder_pro_max_files' => 1000,
            'module_image_finder_pro_preview' => 1
        );
        
        $this->model_setting_setting->editSetting('module_image_finder_pro', $settings);
    }

    public function uninstall() {
        $this->load->model('setting/setting');
        $this->model_setting_setting->deleteSetting('module_image_finder_pro');
    }

    protected function validate() {
        if (!$this->user->hasPermission('modify', 'extension/module/image_finder_pro')) {
            $this->error['warning'] = $this->language->get('error_permission');
        }

        return !$this->error;
    }
}
