/**
 * Image Finder Pro JavaScript
 */
if (typeof ImageFinderPro === 'undefined') {
    var ImageFinderPro = {
        init: function() {
            console.log('Image Finder Pro initialized');
        },
        
        showPreview: function(imagePath) {
            var imageUrl = baseUrl + 'image/' + imagePath;
            $('#preview-image').attr('src', imageUrl);
            $('#imagePreviewModal').modal('show');
        },
        
        getFileInfo: function(imagePath, callback) {
            $.ajax({
                url: 'index.php?route=extension/module/image_finder_pro/getFileInfo&user_token=' + user_token,
                type: 'post',
                data: { image: imagePath },
                dataType: 'json',
                success: callback
            });
        }
    };
}

$(document).ready(function() {
    ImageFinderPro.init();
});
