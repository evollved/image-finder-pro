<?php
// Heading
$_['heading_title'] = 'Image Finder Pro';

// Text
$_['text_extension'] = 'Extensions';
$_['text_success'] = 'Success: You have modified Image Finder Pro module!';
$_['text_edit'] = 'Edit Image Finder Pro Module';
$_['text_success_find'] = 'Success: Unused images found!';
$_['text_success_delete'] = 'Success: %s images deleted successfully!';
$_['text_loading'] = 'Loading...';
$_['text_no_images'] = 'No unused images found';
$_['text_found_images'] = 'Found %s unused images';
$_['text_recursive_search'] = 'Recursive search in subdirectories';
$_['text_max_files'] = 'Maximum files to check';
$_['text_enable_preview'] = 'Enable image preview';
$_['text_select_all'] = 'Select All';
$_['text_unselect_all'] = 'Unselect All';
$_['text_delete_selected'] = 'Delete Selected (%s)';
$_['text_preview'] = 'Preview';
$_['text_size'] = 'Size';
$_['text_dimensions'] = 'Dimensions';
$_['text_confirm_delete'] = 'Are you sure you want to delete %s selected images? This action cannot be undone!';

// Entry
$_['entry_status'] = 'Status';
$_['entry_recursive'] = 'Recursive Search';
$_['entry_max_files'] = 'Max Files';
$_['entry_preview'] = 'Image Preview';

// Button
$_['button_find'] = 'Find Unused Images';
$_['button_cancel'] = 'Cancel';
$_['button_save'] = 'Save Settings';
$_['button_delete'] = 'Delete Selected';
$_['button_preview'] = 'Preview Image';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Image Finder Pro module!';
$_['error_max_files'] = 'Max files must be between 100 and 10000';
$_['error_delete'] = 'Error deleting file';
$_['error_file_not_found'] = 'File not found or access denied';
